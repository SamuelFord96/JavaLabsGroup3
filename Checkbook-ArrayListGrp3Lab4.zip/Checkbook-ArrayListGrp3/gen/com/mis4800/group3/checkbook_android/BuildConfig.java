/** Automatically generated file. DO NOT MODIFY */
package com.mis4800.group3.checkbook_android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}