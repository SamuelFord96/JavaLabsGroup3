package com.example.gradegrubber;

/*This is where all the calculation for the grades will be done should be pretty simple
*		Data will be passed through this class, just like with assignment 2, we define our private member variables at the top and then use them throughout
*		then we use getters from the other classes to grab the calculations we did
*/ 

public class Grade_Calculations {

}
