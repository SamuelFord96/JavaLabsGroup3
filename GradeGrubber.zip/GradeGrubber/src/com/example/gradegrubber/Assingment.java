package com.example.gradegrubber;

/* This is a class that we will use to keep track of all the assingments that students add, as well as the points that each assingment has
 * 	then we will funnel all that data into the course activity to be displayed
 * 
 */
public class Assingment {

}
